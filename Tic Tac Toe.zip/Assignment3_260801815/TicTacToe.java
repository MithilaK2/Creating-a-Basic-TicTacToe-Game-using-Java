
// 260801815
// Mithila Kandasamy

//a program that lets the user play a game of Tic Tac Toe with the AI
import java.util.Scanner;
import java.util.Arrays;
import java.util.Random;
public class TicTacToe{
  
  public static void main(String[] args){
    //we call the play method to initialize a game of tic tac toe
    play();
    
    
    
  }
  public static char [][] createBoard(int n){
    //A method called createBoard that takes as input one integer n, 
    //representing the dimension of the board, and returns an n by n array of characters.
    //This 2 dimensional array of characters represents the board of the game.
    char [][] c = new char[n][n];
    //basically we create a for loop to populate the array, and that with empty spaces as this is how intially the board should be
    for (int i = 0; i<c.length;i++){
      for (int j=0;j<c[i].length;j++){
        c[i][j] = ' ';
      }
    }
    return c;
    
    
  }
  public static void displayBoard(char [][] c){
    //A method called displayBoard that takes a 2 dimensional array of character as input and prints out the board.
    //using nested for loops, we separate rows and columns and have the +/-/ patterns on the edge of the board
    //and the | pattern between each empty space
    //using i to represent to rows and j to represent columns
    for(int i = 0;i<2*c.length+1;i++){
      if (i%2!=0){
        for(int j = 0;j<2*c.length+1;j++){
          if(j%2==0) {
            System.out.print("|");
          } else {
            
            //k is to represent the space between the patternw where the players can put their variable (x/o)
            for(int k= 0; k<c.length; k++){
              for(int l =0; l<c[k].length;l++){
                if(i ==  2*k+1 && j == 2*l+1){
                  System.out.print(c[k][l]);
                  
                }
              }
              
            }
            
          }
          
        }
      } 
      else {
        for(int j=0;j<2*c.length+1;j++){
          if(j%2!=0){
            
            System.out.print("-");
            
          } else {
            System.out.print("+");
          }
        }
      }
      System.out.println();
      
    }
    
  }
  public static void writeOnBoard(char [][] c,char a,  int x, int y){
    //A method called writeOnBoard that takes as input the board (a 2 dimensional array of character), the character to write (a), 
    //and two integers x and y representing the position on the board where the character should be written on.
    
    if (x>=c.length || y>=c.length || x<0 || y< 0){
      //if the coordinates received represent a cell outside of the board then we throw an ArrayIndexOutOfBondException
      
      throw new ArrayIndexOutOfBoundsException ("This position does not represent a cell on the board!");
      
    }
    //if the cell is empty and does not represent a cell outside of the board then we can put an element of the array and we populate it by using a for loop
    //again i represent the row and j represent the column
    for (int i = 0; i< c.length; i++){ 
      
      for(int j = 0; j<c.length;j++){
        if (x==i && y ==j){
          if(c[i][j] == ' '){
            c[i][j] = a;
            
          }
          
          else { 
            // if the cell already contain a character that is not the space character then we throw an Illegal Argument Exception saying the space is already occupied
            throw new IllegalArgumentException("This cell position already has a character!"); 
          }
          
        }
      }
    }
    
  }
  public static void getUserMove(char [][] c){
    //A method called getUserMove that takes the board as input and returns no value. 
    //This method uses Scanner to get a move from the user. 
    //A move is composed by two integers representing the position on the board where the user wants to write their symbol (‘x’)
    int row;
    int column;
    Scanner read = new Scanner(System.in);
    //using the integers 'row and 'column' these will be the coordinates to input character x(User's input) 
    System.out.println("Please enter your move: ");
    row = read.nextInt();
    column = read.nextInt();
    //If the move is invalid (such cell does not exist on the board, or it is already occupied by an ‘x’ or an ‘o’), then we ask the user to enter a new move. 
    //we keep asking the user for a new move, until they enter a valid one. 
    while (row>=c.length || column>=c.length || row<0 || column< 0){
      System.out.println("Please enter valid move: ");
      row = read.nextInt(); 
      column = read.nextInt();
    } 
    
    while (c[row][column] != ' '){      
      System.out.println("Please enter valid move: ");
      row = read.nextInt();
      column = read.nextInt();     
    }
    //Once the method receives a valid move, it carries it out by calling the writeOnBoard method with the appropriate inputs.
    if(c[row][column]==' ') {
      writeOnBoard(c,'x',  row, column);    
    }
    
  }
  
  public static boolean checkForObviousMove(char[][]c){
    //A method called checkForObviousMove that takes the board as input and returns true if there’s an “obvious move” the AI should do, 
    //false otherwise. We consider to be an “obvious move” a move that would make the AI either win or avoid an obvious win for the user on the next turn. 
    //If such a move exist, then the method should carry it out by calling the writeOnBoard method with the appropriate inputs, and then return true.
    int addX = 1;
    int addY =1;
    int sumO = 0; 
    int sumX = 0;
    //the way this method is made is by creating a nested for loop where x represents the row and y represents the column 
    //where it looks at each element of the array. It initially asks if the cell is empty and if so then we can now check when to make an obvious move
    for(int x = 0; x<c.length;x++){
      for(int y=0;y<c.length;y++){
        if (c[x][y]==' '){
          //the position is at the last column but anywhere in the row
          if(y>=c.length-1){
            //then we will intialize the variables of addX addY sumO and sumX
            //Basically the 'add' variable adds/subtracts the position of the array to look at. 
            //for instance, here we keep x(row) of an element intact and 
            // since we're looking at the last column, we then look at every element in the column of this row before this element
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            while (y>1 && y-addY>=0) {
              //we condition an if statement to look if every column position before c[x][y] position is taken by x or o. if its x then all other positions should be o.
              //or else we look the second while loop that is the same while loop as this but it evaluates if all column positions before c[x][y] is o.
              if(c[x][y-addY] == 'o' ){
                //at every iteration, we add 1 to the 'sum'
                //for instance, in this case, since we know that y is at the last column, hence if all column positions (keeping row position intact)
                //before position at x and y are the same this will add the sum everytime it is the same
                sumX +=1;
                
              }
              //so that it does not skip a position, if the next position evaluated at next iteration doesnt have the same character as the previous one then while loop breaks
              else {
                
                break;
                
              }
              
              addY++; 
              //the sum is then used to see if the number of iterations is the same as the number of elements in a column/row without lookin at position at x and y
              //this works since the sum represents the number of iterations evaluated 
              //since here we are looking at the position at the last column which represents (c.length-1) and we want to look at all positions before this position
              //which obviouls means the loop iterates (c.length-1) times. hence if we subtract y (column position) by the sum (number of iterations) it should give 0.
              if(y-sumX==0){
                //if the subtraction gives 0 then can call the writeOnBoard to input the AI's variable at position x and y since this is an obvious move
                writeOnBoard(c,'o',  x, y);
                return true;
              }
            }
            //we need to initialize the 'add' and sum' variables at every while statement in case if there were modified because of th previous while statement
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            while (y>1 && y-addY>=0) {
              
              if(c[x][y-addY] == 'x' ){
                sumO +=1;
                
              }
              
              else {
                
                break;
                
              }
              
              addY++;  
              if(y-sumO==0){
                writeOnBoard(c,'o',  x, y);
                return true;
              }
            }
            
          }
          //this is when the column position stays intact, but we vary the row position to see if there's an obvious move
          if(x<c.length-1 && x>=0){
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            while (x<c.length-1 && x+addX<c.length) {
              
              
              if((c[x+addX][y] == 'o' )){
                sumX +=1;
                //this if statement is needed as, if the position is not c[0][0], then it means the position is somewhere in the middle 
                //so we need to look at all row positions to its right AND  to its left and it needs to iterate to true if each of those positions have the same character
                if(x>0  && x-addX>=0){
                  addX=1;
                  if((c[x-addX][y] == 'o' )){
                    sumX +=1;
                    
                  } 
                }
              }  
              else {
                
                break;
                
              }
              addX++; 
              //since we want the sum to be equal to (c.length-1) (all positions are looked except for position at x and y) we create an if statement to see if it is
              //so that if it is true then we can call the writeOnBoard method and return true
              
              if(sumX==c.length-1){
                writeOnBoard(c,'o',  x, y);
                return true;
              }
            } 
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            while (x<c.length-1 && x+addX<c.length) {
              
              
              if((c[x+addX][y] == 'x' )){
                sumO +=1;
                if(x>0  && x-addX>=0){
                  addX=1;
                  if((c[x-addX][y] == 'x' )){
                    sumO +=1;
                    
                  } 
                }
              } 
              else {
                
                break;
                
              }
              addX++; 
              if(sumO==c.length-1){
                writeOnBoard(c,'o',  x, y);
                return true;
              }
            }
            
          } 
          //this is the same as the previous if statement,  but this time the column stays intact, and we vary the row position 
          //here the row position is at the very end of the board
          if (x>=c.length-1){
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            while (x>1 && x-addX>=0) {
              if(c[x-addX][y] == 'o' ){
                sumX += 1; 
              }
              else {                 
                break;
                
              }
              
              addX++;  
              if (x-sumX==0){
                writeOnBoard(c,'o',  x, y);
                return true;
              }
              
            }  
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            //while loop for x instead of o
            while (x>1  && x-addX>=0) {
              if(c[x-addX][y] == 'x' ){
                sumO += 1; 
              }
              else {                 
                break;
                
              }
              
              addX++;  
              if (x-sumO==0){
                writeOnBoard(c,'o',  x, y);
                return true;
              }
              
            }
          }
          
          //this is when the row position stays intact, but we vary the column position to see if there's an obvious move 
          //this is when the column position somewhere between the begining and the middle
          if (y<c.length-1 && y>=0){
            
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            while (y<c.length-1 && y+addY<c.length) {
              
              if((c[x][y+addY] == 'o')){
                
                
                sumX += 1; 
                if(y>0 && y-addY>=0){
                  addY=1;
                  if((c[x][y-addY] == 'o' )){
                    sumX +=1;
                    
                  } 
                }
              }
              else {
                
                break;
                
              }
              addY++;
              
              if(sumX == c.length-1){
                writeOnBoard(c,'o',  x, y);
                return true;
              }
              
            }
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            //this is again the same while loop as the previous one but looking at conditions for x and not o
            while (y<c.length-1 && y+addY<c.length) {
              
              if((c[x][y+addY] == 'x')){
                
                
                sumO += 1; 
                if(y>0 && y-addY>=0){
                  addY=1;
                  if((c[x][y-addY] == 'x' )){
                    sumO +=1;
                    
                  } 
                }
              }
              else {
                
                break;
                
              }
              addY++;
              
              if(sumO == c.length-1){
                writeOnBoard(c,'o',  x, y);
                return true;
              }
              
            }
            
            
          }
          
          //this is to see if there is an obvious move in the diagonal position 
          //more specifically it is similar to the function y = -x
          // if its at x and y are at the beginning, than we look all positions that are after it,
          // if its at middle then we look at the positions at before it and after it
          if (y<c.length-1 && y>=0 && x<c.length-1 && x>=0){
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            while (y<c.length-1 && x<c.length-1 && y+addY<c.length && x+addX<c.length ) {
              if((c[x+addX][y+addY] == 'o')){
                sumX +=1;
                if(x>0 && y>0 && x-addX>=0 && y-addY>=0){
                  addX = 1;
                  addY=1;
                  if((c[x-addX][y-addY] == 'o')){
                    sumX +=1;
                    
                  }
                  
                  
                }
              }
              else{
                
                break;           
              } 
              
              
              addY++;
              addX++;
              if((sumX==c.length-1)&&(sumX==c.length-1)){
                writeOnBoard(c,'o',  x, y);
                return true;
              }
              
            } 
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            //same while loop statement but x instead of o
            while (y<c.length-1 && x<c.length-1 && y+addY<c.length && x+addX<c.length) {
              if((c[x+addX][y+addY] == 'x')){
                sumO +=1;
                if(x>0 && y>0  && x-addX>=0 && y-addY>=0){
                  addX = 1;
                  addY=1;
                  if((c[x-addX][y-addY] == 'x')){
                    sumO +=1;
                    
                  }
                  
                }
                
              } 
              else{
                
                break;
                
              } 
              
              addY++;
              addX++;
              if((sumO==c.length-1)&&(sumO==c.length-1)){
                writeOnBoard(c,'o',  x, y);
                return true;
              }
              
            }
            
            
          }
          
          //this is to see if there is an obvious move in the diagonal position 
          //more specifically it is similar to the function y = -x
          //this is to look at all positions that are between the beginning and before the last position
          if (x>=c.length-1  && y>=c.length-1){
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            
            while (x>1 && y>1 && x-addX>=0 && y-addY>=0) {
              if(c[x-addX][y-addY] == 'o'){
                sumX +=1;
                
              }
              else {
                
                break;
                
              }
              
              addX++;
              addY++;
              if((x-sumX==0)&&(y-sumX==0)){
                writeOnBoard(c,'o',  x, y);
                return true;
              }
              
            } 
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0; 
            //same while loop as previous one but for x instead of o
            while (x>1 && y>1 && x-addX>=0 && y-addY>=0) {
              if(c[x-addX][y-addY] == 'x'){
                sumO +=1;
                
                
              }
              else {
                
                
                break;
                
              }
              
              addX++;
              addY++;
              if((x-sumO==0)&&(y-sumO==0)){
                writeOnBoard(c,'o',  x, y);
                return true;
              }
              
            }
            
          } 
          //this is to see if there is an obvious move in the diagonal position 
          //more specifically it is similar to the function y = x
          
          if (y<c.length-1 && y>=0 && x>=c.length-1){
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            while (x>1 && y<c.length-1 && x-addX>=0 && y>=0 && y+addY<c.length) {
              
              if((c[x-addX][y+addY] == 'o')){
                sumX +=1;
                
              }
              else {
                
                
                break;
              }
              
              addX++;
              addY++;
              if((x-sumX==0)&&(y+sumX==c.length-1)){
                writeOnBoard(c,'o',  x, y);
                return true;
              }
              
            } 
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            //while looop for x instead of o
            while (x>1 && y<c.length-1 && x-addX>=0 && y>=0 && y+addY<c.length) {
              
              if((c[x-addX][y+addY] == 'x')){
                sumO +=1;
                
              }
              else {
                
                
                break;
              }
              
              addX++;
              addY++;
              if((x-sumO==0)&&(y+sumO==c.length-1)){
                writeOnBoard(c,'o',  x, y);
                return true;
              }
              
            }
            
            
          } 
          //this is to see if there is an obvious move in the diagonal position 
          //more specifically it is similar to the function y = x
          if (y>=c.length-1 && x<c.length-1 && x>=0){
            
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;  
            while (x<c.length-1 && y>1 && x+addX<c.length && y-addY>=0) {
              
              if((c[x+addX][y-addY] == 'o' )){
                sumX+=1;
                
                
              }
              else {
                
                break;
                
              }
              
              addX++;
              addY++;
              if((sumX==c.length-1)&&(y-sumX==0)){
                writeOnBoard(c,'o',  x, y);
                return true;
                
              }
              
            } 
            addX = 1;
            addY =1;
            sumO = 0; 
            sumX = 0;
            //while loop for x instead of o
            while (x<c.length-1 && y>1 && x+addX<c.length && y-addY>=0) {
              
              if((c[x+addX][y-addY] == 'x' )){
                sumO+=1;
                
                
              }
              else {
                
                break;
                
              }
              
              
              addX++; 
              addY++;
              
              if((sumO==c.length-1)&&(y-sumO==0)){
                writeOnBoard(c,'o',  x, y);
                return true;
                
              }
              
            }  
          } 
          
        }
        
      }
    } 
    //if its not an obvious move then we return false
    return false; 
  }
  public static void getAIMove(char [][] c){
    //A method called getAIMove that takes the board as input and returns no value. 
    //This method should first check whether an “obvious move” is possible for the AI and carry it out by calling the checkForObviousMove method.    
    
    boolean obviousMove = checkForObviousMove(c);
    Random randomGenerator = new Random();
    int x = randomGenerator.nextInt(c.length);
    int y = randomGenerator.nextInt(c.length);
    
    //If no “obvious move” was possible, then the method uses the Random class to generate a move for the AI.
    if (obviousMove==false){
      
      if (c[x][y]==' '){
        writeOnBoard(c,'o', x, y);
        
      } else {
        //If the move generated is invalid (the cell is already occupied by a character that is not a space), 
        //then the method generates a new one. Once the method has generated a valid move, 
        while(c[x][y]!=' ') {
          //then it carries it out by calling the writeOnBoard method with the appropriate inputs.
          
          x = randomGenerator.nextInt(c.length);
          y = randomGenerator.nextInt(c.length);
          
          
        }
        writeOnBoard(c,'o', x, y);
        
      }
    }    
    
  }
  public static char checkForWinner(char[][]c){
    //a method called checkForWinner that takes the board as input and returns a character.
    //The method should check whether either the user or the AI have won the game. If the user won the game, 
    //then the method returns ‘x’, if the AI won the game then it returns ‘o’, if there is no 
    //winner yet it returns ‘ ’ (the space character!).
    
    //this is very similar to the checkForObvious method in that instead of returning true it returns o or x depending who won
    //exact same conditions as the checkForObvious method but another change is that the add variable starts at 0 since 
    //we have to also include checking at if position at x and y have the same character as the rest of the positions
    int add = 0;
    int sum = 0;
    char x = 'x';
    char o = 'o';
    char space = ' ';
    for(int i = 0; i<c.length;i++){
      for(int j=0;j<c.length;j++){
        
        if(j>=c.length-1){
          add = 0;
          sum = 0;
          while (j>1 && j-add>=0) {
            
            if(c[i][j-add] == 'x' ){
              sum +=1;
              
            }
            
            else {
              
              break;
              
            }
            
            add++;  
            if(j-sum==-1){
              
              return x;
            }
          }
          add = 0;
          sum = 0;
          while (j>1 && j-add>=0) {
            
            if(c[i][j-add] == 'o' ){
              sum +=1;
              
            }
            
            else {
              
              break;
              
            }
            
            add++;  
            if(j-sum==-1){
              
              return o;
            }
          }
          
        }    
        if(i<c.length-1 && i>=0){
          add = 0;
          sum = 0;
          while (i<c.length-1 && i+add<=c.length-1) {
            
            
            if(c[i+add][j] == 'x' ){
              sum +=1;
              
            } 
            else {
              
              break;
              
            }
            add++; 
            if(sum==c.length){
              
              return x;
            }
          } 
          add = 0;
          sum = 0;
          while (i<c.length-1 && i+add<=c.length-1) {
            
            
            if(c[i+add][j] == 'o' ){
              sum +=1;
              
            } 
            else {
              
              break;
              
            }
            add++; 
            if(sum==c.length){
              
              return o;
            }
          }
          
        }  
        if (i>=c.length-1){
          add = 0;
          sum = 0;
          while (i>1 && i-add>=0) {
            if(c[i-add][j] == 'x' ){
              sum += 1; 
            }
            else {                 
              break;
              
            }
            
            add++;  
            if (i-sum==-1){
              
              return x;
            }
            
          }  
          add = 0;
          sum = 0;
          while (i>1 && i-add>=0) {
            if(c[i-add][j] == 'o' ){
              sum += 1; 
            }
            else {                 
              break;
              
            }
            
            add++;  
            if (i-sum==-1){
              
              return o;
            }
            
          }
        }
        
        
        if (j<c.length-1 && j>=0 && j+add<=c.length-1){
          add = 0;
          sum = 0;
          
          while (j<c.length-1 && j+add<=c.length-1) {
            
            if((c[i][j+add] == 'x')){
              
              
              sum += 1; 
              
            }
            else {
              
              break;
              
            }
            add++;
            
            if(sum == c.length){
              
              return x;
            }
            
          }
          add = 0;
          sum = 0;
          while (j<c.length && j+add<=c.length-1) {
            
            if((c[i][j+add] == 'o')){
              
              
              sum += 1; 
              
            }
            else {
              
              break;
              
            }
            add++;
            
            if(sum == c.length){
              
              return o;
            }
            
          }
          
        }
        
        
        if (j<c.length-1 && j>=0 && i<c.length-1 && i>=0){
          add = 0;
          sum = 0;
          while (j<c.length-1 && i<c.length-1  && j+add<=c.length-1 && i+add<=c.length-1) {
            if(c[i+add][j+add] == 'x'){
              sum +=1;
              if(i>0 && j>0  && i-add>=0 && j-add>=0){
                
                add=1;
                if((c[i-add][j-add] == 'x')){
                  sum +=1;
                  
                }                
                
              }
            } 
            else{
              
              break;           
            } 
            
            
            add++;
            if((sum==c.length)&&(sum==c.length)){
              
              return x;
            }
            
          } 
          add = 0;
          sum = 0;
          while (j<c.length-1 && i<c.length-1 && j+add<=c.length-1 && i+add<=c.length-1) {
            if(c[i+add][j+add] == 'o'){
              sum +=1;
              if(i>0 && j>0  && i-add>=0 && j-add>=0){
                add = 1;
                
                if((c[i-add][j-add] == 'o')){
                  sum +=1;
                  
                }
                
                
              }
              
            } 
            else{
              
              break;
              
            } 
            
            
            add++;
            if((sum==c.length)&&(sum==c.length)){
              
              return o;
            }
            
          }
          
          
        }
        
        if (i>=c.length-1  && j>=c.length-1){
          add = 0;
          sum = 0;
          while (i>1 && j>1 && i-add>=0 && j-add>=0) {
            if(c[i-add][j-add] == 'x'){
              sum +=1;
              
            }
            else {
              
              break;
              
            }
            
            add++;
            if((i-sum==-1)&&(j-sum==-1)){
              
              return x;
            }
            
          } 
          add = 0;
          sum = 0;
          while (i>1 && j>1 && i-add>=0 && j-add>=0) {
            if(c[i-add][j-add] == 'o'){
              sum +=1;
              
            }
            else {
              
              break;
              
            }
            
            add++;
            if((i-sum==-1)&&(j-sum==-1)){
              
              return o;
            }
            
          }
          
        }if (j<c.length-1 && j>=0 && i>=c.length-1){
          add = 0;
          sum = 0;
          while (i>1 && j<c.length-1 && i-add>=0 && j+add<=c.length-1) {
            
            if(c[i-add][j+add] == 'x'){
              sum +=1;
              
            }
            else {
              
              
              break;
            }
            
            add++;
            if((i-sum==-1)&&(sum==c.length)){
              
              return x;
            }
            
          } 
          add = 0;
          sum = 0;
          while (i>1 && j<c.length-1 && i-add>=0 && j+add<=c.length-1) {
            
            if(c[i-add][j+add] == 'o'){
              sum +=1;
              
            }
            else {
              
              
              break;
            }
            
            add++;
            if((i-sum==-1)&&(sum==c.length)){
              
              return o;
            }
            
          }
          
        }if (j>=c.length-1 && i<c.length-1 && i>=0){
          
          add = 0;
          sum = 0; 
          while (i<c.length-1 && j>1 && i+add<=c.length-1 && j-add>=0) {
            
            if(c[i+add][j-add] == 'x' ){
              sum+=1;
              
              
            }
            else {
              
              break;
              
            }
            
            add++;
            if((sum==c.length)&&(j-sum==-1)){
              
              return x;
              
            }
            
          }
          add = 0;
          sum = 0;
          while (i<c.length-1 && j>1 && i+add<=c.length-1 && j-add>=0) {
            
            if(c[i+add][j-add] == 'o' ){
              sum+=1;
              
              
            }
            else {
              
              break;
              
            }
            
            
            add++; 
            
            if((sum==c.length)&&(j-sum==-1)){
              
              return o;
              
            }
            
          }
          
        } 
        //if neither the user nor AI won and there are still space available, then it needs to return space
        else if (c[i][j] == space){
          return space;
        }
        
      }
      
      
    } 
    //if the theres no space at all and neither the  user nor the AI won , then we will return null so the end can end here
    char nl = (char) 0;
    return nl;
  }
  
  public static void play(){
    // A method called play that takes no inputs and returns no value. 
    //  This method should implement a game of Tic Tac Toe between the user and the AI using all the methods previously defined. 
    //  The method uses Scanner to take inputs from the user.
    // The method can carry out a game of Tic Tac Toe.
    
    //we declare variables for chars x, y and space to use them in the statements below
    char x = 'x';
    char o = 'o';
    char space = ' ';
    String name;
    char dimension;
    
    Scanner read = new Scanner(System.in);
    // Before beginning the actual game, the method should ask the user for their name and store it in an appropriate variable. 
    System.out.print("What’s your name? ");
    name = read.nextLine();
    System.out.println("Welcome " + name + "! Are you ready to play?");
    name = " " + x;
    //  Then, the method should ask the user for an integer indicating the dimension of the board the user wants to play with. 
    
    System.out.println("Please choose the dimension of your board: ");
    dimension = read.next().charAt(0);
    // If the user does not input an integer, then the method should keep asking for an input of the correct type until it receives one.
    //using character variable to check that if its not between 0 and 9 then it should keep on asking to type correct dimension
    //hence one should remember that any number higher than 9 should type it character-wise
    while (dimension>=58 || dimension <=47){
      
      System.out.println("Please choose a correct dimension of your board: ");
      
      dimension = read.next().charAt(0);
      
    } 
    
    int trueDimension = Integer.parseInt(""+dimension);
    char [][] c =  createBoard(trueDimension); 
    //It first creates a board with the correct dimension, then flip a coin to decide whether the user or the AI should start to play.
    //using math random we think of 0 for the user and 1 for the AI
    // The method should print out the result of the coin toss so that the user knows who has the first move. 
    
    int toss = (int) (Math.random()*2);
    
    System.out.println("The result of the coin toss is " + toss);
    //we create an if statement for if AI won the coin toss 
    if(toss==1) {
      System.out.println("The AI has the first move");    
      //using a while loop to have the conditions that, as long as cell of the board has a space, then the user or the AI can make their move
      while(checkForWinner(c) ==space){
        //After the order of the players has been decided, the players alternate each other in making a move.
        //we do this using the getAImove and getUserMove methods
        System.out.println("The AI made his move: ");
        
        getAIMove(c);
        //The method should display the updated board each time a move is made.
        //The players keep taking turns until either one of them wins or there are no more available moves
        displayBoard(c);
        //we break the while loop if theres a winner or theres no longer a space in the board
        if (checkForWinner(c)== x || checkForWinner(c) == o || checkForWinner(c) != space ) {
          break;
        }
        
        
        getUserMove(c);
        displayBoard(c);
        
        if (checkForWinner(c)== x || checkForWinner(c) == o || checkForWinner(c) != space ) {
          break;
        }
        
      }
      
    }
    //using an else if statement to have condition of if the user won the coin toss
    else if(toss==0) {
      System.out.println("You have the first move");
      
      while(checkForWinner(c) ==space){
        getUserMove(c); 
        displayBoard(c);
        if (checkForWinner(c)== x || checkForWinner(c) == o || checkForWinner(c) != space ) {
          break;
        }
        
        System.out.println("The AI made his move: ");
        getAIMove(c); 
        displayBoard(c);
        if (checkForWinner(c)== x || checkForWinner(c) == o) {
          break;
        }
      }
      
    }
    //at the end of the game, we print who won the game or if no one the game using if, else if, else statements
    if (checkForWinner(c)== x) {
      System.out.println("GAME OVER" + "\n" + "You won!");
    } 
    else if (checkForWinner(c)== o) {
      System.out.println("GAME OVER" + "\n" + "You lost!");
    } else   {
      System.out.println("GAME OVER" + "\n" + "No one won the game!");
    }
  } 
  
} 
